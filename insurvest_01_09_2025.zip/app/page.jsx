//import Insurance from "./home/insurance/page";
import AgencyModern from "./home/agency-modern/page";
export const metadata = {
  title: "INSURVEST | Claim Specialists",
};
const MainRoot = () => {
  return <AgencyModern />;
};

export default MainRoot;
